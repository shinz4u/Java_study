package com.company;
import java.util.*;

public class MyMain {

    public static void main(String[] args) {





        System.out.println("How are you, I am using IntelliJ Java IDE ");



    }
}
